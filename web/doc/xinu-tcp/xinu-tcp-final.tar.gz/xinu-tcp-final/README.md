NOTA DE RAFA:

Iniciar XINU
Ejecutar 
client gnu.msn.by 80 /

Unas 3 veces y falla.



xinu-pc es el xinu que usamos con rafa durante la cursada, donde meti los archivos TCP del xinu mas viejito.
xinu-tcp2 es el xinu viejito con tcp
ignoren xinu-tcpnosirve

En notas.odt estan TODOS los archivos que tienen la palabra "TCP" escrita. Por si quieren chusmearlos.

Los dos tar.gz son para exportar el xinu-pc y el xinu-tcp2
