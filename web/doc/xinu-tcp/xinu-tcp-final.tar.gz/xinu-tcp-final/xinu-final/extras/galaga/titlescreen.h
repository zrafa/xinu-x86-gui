#ifndef TITLESCREEN_BITMAP_H
#define TITLESCREEN_BITMAP_H
extern const unsigned short titlescreen[38400];
#define TITLESCREEN_WIDTH 240
#define TITLESCREEN_HEIGHT 160
#endif