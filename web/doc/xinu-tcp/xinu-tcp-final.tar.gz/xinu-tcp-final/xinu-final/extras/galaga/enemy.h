#ifndef ENEMY_BITMAP_H
#define ENEMY_BITMAP_H
extern const unsigned short enemy[400];
#define ENEMY_WIDTH 20
#define ENEMY_HEIGHT 20
#endif