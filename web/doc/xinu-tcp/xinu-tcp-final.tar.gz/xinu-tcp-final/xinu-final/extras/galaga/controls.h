#ifndef CONTROLS_BITMAP_H
#define CONTROLS_BITMAP_H
extern const unsigned short controls[38400];
#define CONTROLS_HEIGHT 160
#define CONTROLS_WIDTH 240
#endif