#ifndef SHOOT_BITMAP_H
#define SHOOT_BITMAP_H
extern const unsigned short shoot[400];
#define SHOOT_WIDTH 20
#define SHOOT_HEIGHT 20
#endif
